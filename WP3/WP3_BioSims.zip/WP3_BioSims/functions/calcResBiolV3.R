calcRes <-function(resultsObject)
{
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # calRes
  # function that takes the resObj and calculates 
  # various results from it
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  # functions
  lengthUnique <- function(x){length(unique(x))}
  asCharacterUnique <- function(x){unique(as.character(x))}
  
  out <- list()
  
  if (!is.null(names(resultsObject)[1])){
    if (names(resultsObject)[1]=="sampRowNames") {
      resultsObject_lst <- list()
      resultsObject_lst[[1]] <- resultsObject
      resultsObject <- resultsObject_lst}}
  
  for (idx in 1:length(resultsObject)){
    
    # reassigning a resultsObject for plots and summsry stats. 
    a <-resultsObject[[idx]]
    simSppEst  <-a$sppEst
    simSppSize <-a$sppNumber
    simDomSize <-a$domainNumber
    
    pop <-a$pop
    
    simTotEst    <-a$totalEst
    simCtryEst   <-a$ctryEst
    simDomEst    <-a$domainEst
    
    sppList  <-a$sppList
    ctryList <-a$ctryList
    domList  <-a$domainList
    
    len_vec <- as.numeric(names(pop)[13:c(ncol(pop)-9)])
    
    # standardise all to 100 (i.e. get frequency of distributions obtained in each sim before averageing etc)
    sums <- apply(simSppEst[,1:c(dim(simSppEst)[2]/2),],2,sum,na.rm=T)
    simSppEst <- sweep(simSppEst[,1:c(dim(simSppEst)[2]/2),], 2, sums, FUN = '/')
    
    sums <- apply(simTotEst[,1:c(dim(simTotEst)[2]/2)],1,sum,na.rm=T)
    simTotEst <- sweep(simTotEst[,1:c(dim(simTotEst)[2]/2)], 1, sums, FUN = '/')
    
    # keep only the numbers, not s.e.
    simCtryEst <- simCtryEst[,1:c(dim(simCtryEst)[2]/2),]
    # sums <- apply(simCtryEst[,1:c(dim(simCtryEst)[2]/2),],3,sum,na.rm=T)
    # simCtryEst <- sweep(simCtryEst[,1:c(dim(simCtryEst)[2]/2),], 3, sums, FUN = '/')
    # 
    simDomEst <- simDomEst[,1:c(dim(simDomEst)[2]/2),]
    # sums <- apply(simDomEst[,1:c(dim(simDomEst)[2]/2),],3,sum,na.rm=T)
    # simDomEst <- sweep(simDomEst[,1:c(dim(simDomEst)[2]/2),], 3, sums, FUN = '/')
    # 
    
    # calculate summary statistics
    
    # population
    # Calculate weighted mean length for pop
    sppPop_tmp      <- apply(pop[,13:c(ncol(pop)-9)],2,sum)
    sppPop          <- sum(sppPop_tmp*len_vec)/sum(sppPop_tmp)
    
    sppPopSize    <- tapply(pop$fishTripId,pop$sppFac,lengthUnique)
    
    # samples
    # can keep frequency or get mean length - we go for mean length here
    meanSppEst  <- mean(apply(simSppEst*len_vec,2,sum,na.rm=T))
    sdSppEst    <- sd(apply(simSppEst*len_vec,2,sum,na.rm=T))
    sppSampSize <- colMeans(simSppSize)     
    
    #meanSdSppEst <- apply(simSppEst[,c(dim(simSppEst)[2]/2+1):dim(simSppEst)[2],],1,mean,na.rm=T) # not applicable as got rid of the s.e. when standardising
    ciLoSppEst   <- quantile(apply(simSppEst*len_vec,2,sum,na.rm=T),0.025,na.rm=T)
    ciUpSppEst   <- quantile(apply(simSppEst*len_vec,2,sum,na.rm=T),0.975,na.rm=T)
    RSEest <- sdSppEst/meanSppEst
    
    sppRSE <- mean(RSEest,na.rm=T)
    
    # should be same as above here
    meanTotEst <- mean(apply(t(simTotEst)*len_vec,2,sum,na.rm=T))
    sdTotEst   <- sd(apply(t(simTotEst)*len_vec,2,sum,na.rm=T))
    totRSEest  <- sdTotEst/meanTotEst
    
    # pop vs samples
    sppBiasEst    <- 100*(meanSppEst/sppPop-1)

    # # mean RSE over fish species and country
    # sppRSE <- mean(RSEest,na.rm=T)
    
    # calculate pop meanL
    Pop <- sppPop
    
    ## domains
    # population
    # Calculate weighted mean length for domains
    domainPop_tmp       <- mapply(rowsum, as.data.frame(pop[,13:c(ncol(pop)-9)]), as.data.frame(pop$domainsId))
    len_mat <- matrix(len_vec, ncol=length(len_vec), nrow=nrow(domainPop_tmp), byrow=T)
    domainPop           <- as.array(apply(domainPop_tmp*len_mat,1,sum)/apply(domainPop_tmp,1,sum))
    
    dimnames(domainPop)[[1]]    <- sort(unique(pop$domainsId))
    
    # samples
    # this is the mean, sd and quantiles of the simulations
    doms <- dimnames(simDomEst)[[1]]
    
    meanDomEst <- array(NA, dim=c(length(doms),1))
    sdDomEst <- array(NA, dim=c(length(doms),1))
    ciLoDomEst <- array(NA, dim=c(length(doms),1))
    ciUpDomEst <- array(NA, dim=c(length(doms),1))
    
    meanDomEst_sims <- array(NA, dim=c(length(doms),nsim))
    
    for (i in 1:dim(simDomEst)[1]){
      simDomEst_tmp <- simDomEst[i,,]
      len_array      <- matrix(rep(len_vec, times=dim(simDomEst_tmp)[2]), nrow=length(len_vec), byrow = F)
      simDomEst_rep    <- apply(simDomEst_tmp*len_array,2,sum,na.rm=T)/apply(simDomEst_tmp,2,sum,na.rm=T)
      meanDomEst_sims[i,] <- simDomEst_rep
      meanDomEst[i,] <- mean(simDomEst_rep,na.rm=T)
      sdDomEst[i,] <- sd(simDomEst_rep,na.rm=T)
      ciLoDomEst[i,] <- quantile(simDomEst_rep,0.025,na.rm=T)
      ciUpDomEst[i,] <- quantile(simDomEst_rep,0.975,na.rm=T)
    }
    
    domainRSEest <- sdDomEst/meanDomEst
    dimnames(domainRSEest)[[1]] <- doms
    domBiasEst <- 100*(meanDomEst/as.vector(domainPop)-1)
    domSampSize   <- colMeans(simDomSize)     
    
    ## countries
    # population
    # following the same calculation as for meanL per species above (sppPop)
    ctryPop_tmp          <- mapply(rowsum, as.data.frame(pop[,13:c(ncol(pop)-9)]), as.data.frame(pop$landCtry))
    ctryPop           <- as.array(apply(ctryPop_tmp*len_vec,1,sum)/apply(ctryPop_tmp,1,sum))
    
    dimnames(ctryPop)[[1]]    <- sort(unique(pop$landCtry))
    
    # samples
    # this is the mean, sd and quantiles of the simulations
    cty <- dimnames(simCtryEst)[[1]]
    
    meanCtryEst <- array(NA, dim=c(length(cty),1))
    sdCtryEst <- array(NA, dim=c(length(cty),1))
    ciLoCtryEst <- array(NA, dim=c(length(cty),1))
    ciUpCtryEst <- array(NA, dim=c(length(cty),1))
    
    for (i in 1:dim(simCtryEst)[1]){
    simCtryEst_tmp <- simCtryEst[i,,]
    len_array      <- matrix(rep(len_vec, times=dim(simCtryEst_tmp)[2]), nrow=length(len_vec), byrow = F)
    simCtryEst_rep    <- apply(simCtryEst_tmp*len_array,2,sum,na.rm=T)/apply(simCtryEst_tmp,2,sum,na.rm=T)
    meanCtryEst[i,] <- mean(simCtryEst_rep,na.rm=T)
    sdCtryEst[i,] <- sd(simCtryEst_rep,na.rm=T)
    ciLoCtryEst[i,] <- quantile(simCtryEst_rep,0.025,na.rm=T)
    ciUpCtryEst[i,] <- quantile(simCtryEst_rep,0.975,na.rm=T)
    }
    
    ctryRSEest <- sdCtryEst/meanCtryEst
    dimnames(ctryRSEest)[[1]] <- cty
    
    # would be the sppBiasEst here probably...
    totBiasEst <- NA
    
    out[[idx]] <-list("totBiasEst"=totBiasEst,"totEst"=simTotEst,"sppPop"=sppPop,"RSEest"=RSEest,
                      "sppRSE"=sppRSE,"meanSppEst"=meanSppEst,"sppEst"=simSppEst,"sppCiLo"=ciLoSppEst,
                      "sppCiUp"=ciUpSppEst,"sppSampSize"=sppSampSize,"sppBiasEst"=sppBiasEst,
                      "domPop"=domainPop, "domRSEest"=domainRSEest,
                      "domEst"=simDomEst,"domEstsims"=meanDomEst_sims,"meanDomEst"=meanDomEst,"domCiUp"=ciUpDomEst,
                      "domCiLo"=ciLoDomEst,
                      "domainPop"=domainPop,"domBiasEst"=domBiasEst,"domSampSize"=domSampSize)
  }
  
  return(out)
}
