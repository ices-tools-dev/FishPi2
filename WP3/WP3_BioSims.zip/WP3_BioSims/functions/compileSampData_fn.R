#Compile biological data
#Function for getting data in the same format + adding other needed stuff

bio_formatting_function <- function(df, sampCtry) {
  
  df <- data.frame(df)
  
  require(lubridate)
  require(dplyr)
  
  df_1 <- mutate(df, sampFishTripId = as.character(sampFishTripId), sampType = as.character(sampType), vslFlgCtry = as.character(vslFlgCtry),
                 sampDate = as.Date(sampDate, format = '%Y-%m-%d'), loc = as.character(loc), vslLenCls = as.character(vslLenCls), 
                 area = as.character(area), foCatEu6 = as.character(foCatEu6), sppCode = as.character(sppCode), sppName = as.character(sppName),
                 catchWt = as.numeric(catchWt), catchCat = as.character(catchCat), lenCls = as.integer(lenCls), estNum = as.numeric(estNum), 
                 sampNum = as.numeric(sampNum))
  
  df_2 <- mutate(df_1, year = year(sampDate), quarter = quarter(sampDate), sampCtry = sampCtry)
  return(df_2)

}



#Function for correcting loc in sample data 

bio_correcting_loc_function <- function(df){
  
  df <- data.frame(df)
  require(dplyr)
  
  df_1 <- mutate(df, loc = ifelse(!(is.na(loc)) & sampCtry == "NLD" & substr(loc, 1, 2) != "NL", paste("NL", loc, sep = ""), 
                                  ifelse(loc == "ADK", "FRGPO", 
                                         ifelse(loc == "DKQSB", "DKOTB", loc))))
  
  return(df_1)
}



#Function for correcting foCatEu6 in sample data


bio_correcting_foCatEu6_function <- function(df){
  
  df <- data.frame(df)
  require(dplyr)
  require(stringr)
  
  df_1 <- mutate(df, foCatEu6_new = ifelse(sampCtry == "FRA" & substr(foCatEu6, 11, 11) == "_" & substr(foCatEu6, 12, 12) != "0", paste(substr(foCatEu6, 1, 10), "-", substr(foCatEu6,12,20), sep = ""),
                                           ifelse(sampCtry == "FRA" & substr(foCatEu6, 12, 12) == "_" & substr(foCatEu6, 13, 13) != "0", paste(substr(foCatEu6, 1, 11), "-", substr(foCatEu6,13,20), sep = ""), 
                                                  foCatEu6)))
  
  df_1 <- mutate(df_1, foCatEu6 = ifelse(sampCtry == "FRA" & !(substr(foCatEu6_new, 5, 13) %in% c("DEF_0_0_0", "CEP_0_0_0", "MIS_0_0_0")),
                                         str_replace_all(foCatEu6_new, c("_0" = "_0_0", "DEF_0_0_0_0_0" = "DEF_0_0_0")), 
                                         ifelse(foCatEu6_new  %in% c("No_logbook6", "No_logbook6_>10"), "MIS_MIS_0_0_0", foCatEu6_new)))
  
  return(select(df_1, -foCatEu6_new))
  
}