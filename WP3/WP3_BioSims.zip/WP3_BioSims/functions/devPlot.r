#--------------bias and var plot v pop weight----------------------

devPlot <-function(calcs,...)
{
#par(ask=T)
par(mfrow=c(2,1))
dots <- list(...)   
if (is.null(dots$ylim))dots$ylim <-c(min(calcs$sppCiUp,na.rm=TRUE)*0.8,max(calcs$sppCiUp,na.rm=TRUE)*1.2)
if (is.null(dots$xlim))dots$xlim <-c(c(min(calcs$sppPop,na.rm=TRUE)*0.8),c(max(calcs$sppPop,na.rm=TRUE)*1.2))
if (is.null(dots$xlab))dots$xlab <-"True mean length"
if (is.null(dots$ylab))dots$ylab <-"Estimated mean length" 
plot(calcs$sppPop,calcs$meanSppEst,ylim=dots$ylim,xlim=dots$xlim,type="n",xlab=dots$xlab,ylab=dots$ylab)
points(calcs$sppPop,calcs$meanSppEst,pch=16,cex=0.7)
#text(sppPop,meanSppEst,names(sppPop),cex=0.7,pos=rep(c(2,4)10))
text(calcs$sppPop,calcs$meanSppEst,names(calcs$sppPop),cex=0.7,pos=4)
segments(calcs$sppPop,calcs$sppCiLo,calcs$sppPop,calcs$sppCiUp)
abline(0,1,col="grey")
#return("All Done")

if (is.null(dots$ylim))dots$ylim <-c(min(calcs$domCiUp,na.rm=TRUE)*0.8,max(calcs$domCiUp,na.rm=TRUE)*1.2)
if (is.null(dots$xlim))dots$xlim <-c(c(min(calcs$domPop,na.rm=TRUE)*0.8),c(max(calcs$domPop,na.rm=TRUE)*1.2))
if (is.null(dots$xlab))dots$xlab <-"True mean length"
if (is.null(dots$ylab))dots$ylab <-"Estimated mean length" 
plot(calcs$domPop,calcs$meanDomEst,ylim=dots$ylim,xlim=dots$xlim,type="n",xlab=dots$xlab,ylab=dots$ylab)
points(calcs$domPop,calcs$meanDomEst,pch=16,cex=0.7)
#text(sppPop,meanSppEst,names(sppPop),cex=0.7,pos=rep(c(2,4)10))
text(calcs$domPop,calcs$meanDomEst,names(calcs$domPop),cex=0.7,pos=4)
segments(calcs$domPop,calcs$domCiLo,calcs$domPop,calcs$domCiUp)
abline(0,1,col="grey")

}


biasPlot <-function(calcs,spNames=NULL,...)
{
  par(mfrow=c(2,1))
dots <- list(...)   
if (is.null(dots$ylim))dots$ylim <-c(-20,20)
if (is.null(dots$xlab))dots$xlab <-"Sample size"
if (is.null(dots$ylab))dots$ylab <-"% deviation"        
if (is.null(dots$xlim))dots$xlim <-c(c(min(calcs$sppSampSize,na.rm=TRUE)*0.8),c(max(calcs$sppSampSize,na.rm=TRUE)*1.2))

plot(calcs$sppSampSize,calcs$sppBiasEst,type="n",xlim=dots$xlim,ylim=dots$ylim,xlab=dots$xlab,ylab=dots$ylab)
points(calcs$sppSampSize,calcs$sppBiasEst,pch=16,cex=0.7)
#text(sppSampSize,sppBiasEst,names(sppSampSize),cex=0.7)
if (is.null(spNames)) text(calcs$sppSampSize,calcs$sppBiasEst,names(calcs$sppSampSize),cex=0.7,pos=1)
if (!is.null(spNames)) text(calcs$sppSampSize,calcs$sppBiasEst,
                            spNames$name[spNames$code%in%names(calcs$sppSampSize)],cex=0.7,pos=4)
abline(h=c(-10,-5,5,10),col="grey")
abline(h=c(0),col="grey",lty=2)
#return("All Done")

dots <- list(...)   
if (is.null(dots$ylim))dots$ylim <-c(-20,20)
if (is.null(dots$xlab))dots$xlab <-"Sample size"
if (is.null(dots$ylab))dots$ylab <-"% deviation"        
if (is.null(dots$xlim))dots$xlim <-c(c(min(calcs$domSampSize,na.rm=TRUE)*0.8),c(max(calcs$domSampSize,na.rm=TRUE)*1.2))

plot(calcs$domSampSize,calcs$domBiasEst,type="n",xlim=dots$xlim,ylim=dots$ylim,xlab=dots$xlab,ylab=dots$ylab)
points(calcs$domSampSize,calcs$domBiasEst,pch=16,cex=0.7)
#text(sppSampSize,sppBiasEst,names(sppSampSize),cex=0.7)
if (is.null(spNames)) text(calcs$domSampSize,calcs$domBiasEst,names(calcs$domSampSize),cex=0.7,pos=1)
if (!is.null(spNames)) text(calcs$domSampSize,calcs$domBiasEst,
                            spNames$name[spNames$code%in%names(calcs$domSampSize)],cex=0.7,pos=4)
abline(h=c(-10,-5,5,10),col="grey")
abline(h=c(0),col="grey",lty=2)
}
