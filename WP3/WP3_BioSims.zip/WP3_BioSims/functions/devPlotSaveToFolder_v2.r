#--------------bias and var plot v pop weight----------------------

devPlotSaveToFolder <-function(calcs)
{
    
par(ask=F)
    
    mypath <- file.path(myDir,"graphics_output",paste("bias_landed_tons", ".png", sep = ""))
    png(file=mypath, width = 950, height = 700)
    
   devPlot(calcs)
    dev.off()

#-----------------------------------------------------------------------------
#-----------bias plot------------------------------

    mypath <- file.path(myDir,"graphics_output",paste("bias_number_samples", ".png", sep = ""))
    png(file=mypath, width = 950, height = 550)

    biasPlot(calcs)
    
    dev.off()

#------------------------------------------------------------
return("All Done")
}

