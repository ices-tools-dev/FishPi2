domHist <-function(calcs, dom)
{
  suppressMessages(library(fishPiCodes))
  #dom   <- paste(fish,area, sep=".")
  index <- which(dom %in% dimnames(calcs$domEst)[[1]])
  dom   <- dom[index]
  for(i in 1:length(dom)){
    hist(calcs$domEst[dimnames(calcs$domEst)[[1]]==dom[i],],nclass=30,xlab="Estimated mean length",
        density=30,col=2, main=dom[i]) #main=paste(whatFish(fish[i])$English, area[i], sep=" ") ,
    abline(v=calcs$domPop[names(calcs$domPop)==dom[i],],col=3,lty=1,lwd=4)
    abline(v=mean(calcs$domEst[dimnames(calcs$domEst)[[1]]==dom[i],],na.rm=T),col=2,lty=1,lwd=2)
    abline(v=calcs$domCiUp[names(calcs$domPop)==dom[i],],col=2,lty=2)
    abline(v=calcs$domCiLo[names(calcs$domPop)==dom[i],],col=2,lty=2)
  }
}


