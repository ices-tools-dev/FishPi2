runSim <-function(nsim,dat,maxSsuSamp,resObj,sampleForeign=TRUE,saveResults=FALSE,simName="test", replaceResamp = FALSE, verbose=T){
  
  # MAIN CHANGE compared to logbook sims - we add a weight based on total catch to estimate a weighted mean length
  # MAIN CHANGE compared to logbook sims - we use "svymean" instead of "svytotal" as dealing with mean length not total weigth
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # runSim
  # function that runs nsim simulations 
  # from the provided data
  # stratified single stage random sampling 
  # arguments 
  # nsim number of simulations from 1 to many
  # data  - the population data frame with columns for ...
  #   psu - the primary sampling unit
  #   psuStratum the stratum for the psu
  # resObj - a list object with varoius vectors for keeping the simulation results
  # saveResults=FALSE if TRUE the results object will be saved to a file temp in the working directory
  # simName - a character vector for the naming of the simulation 
  # 
  # Returns a resObj the results object a list consisting of:   
  # species estimates
  # ....
  
  # runSim v2 sept 2018
  # changes: 
  # bug fix in sampData is assigned from sampData2 
  # otherwise the number of sampled trips is too large in the two stage sampling
  # line 110-119
  # sampleForeign added that operates on landType ("own" or "foreign") 
  # and mimics the situation where foreign vessels are not sampled on-shore locations
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  suppressMessages(require(survey))
  
  # Run for each element of the list 
  datAll    <- dat
  resObjAll <- resObj
  out       <- list()
  
  # Turn to lists if they are not lists yet (although they should be)
  
  if (is.data.frame(datAll[[1]])) {
    datAll_lst <- list()
    datAll_lst[[1]] <- datAll
    datAll <- datAll_lst}
  if (!is.null(names(resObjAll)[1])){
    if (names(resObjAll)[1]=="sampRowNames") {
    resObjAll_lst <- list()
    resObjAll_lst[[1]] <- resObjAll
    resObjAll <- resObjAll_lst}}
  
  
  for (idx in 1:length(datAll)){
    
    dat    <- datAll[[idx]]
    resObj <- resObjAll[[idx]]
    
    #assign the data to xx
    xx <-dat$data
    sampEffort  <-dat$stratumEffort
    domainNames <-dat$domainNames
    # functions
    lengthUnique <-function(x){length(unique(x))}
    if(all(is.na(xx$ssu))) {
      singleStage <-TRUE
      if (verbose==T) cat("ssu is NA so doing single stage sampling\n")
    }
    if(!(all(is.na(xx$ssu)))) {
      if (verbose==T) cat("ssu is populated so doing two stage sampling\n")
      singleStage <-FALSE
    }
    if(sampleForeign==FALSE) if (verbose==T) cat("Not sampling foreign vessels\n")
    # run the simulations
    if (verbose==T) cat("Starting now\n")
    
    for(i in 1:nsim)
    {
      if (nsim>=10) {
        if ( (i/round(nsim/10)) - (i %/% round(nsim/10)) == 0 ){
          if (verbose==T) print(paste(i,date()))
          flush.console()
        }
      } else {
        if (verbose==T) print(paste(i,date()))
        flush.console()  
      }
      # first we sample the population data frame 
      # selecting the $psu according to psuStratum with the number of samples
      # for each strata given by sampEffort
      selectedPSU <-sampleFromAGroup(xx$psu,xx$psuStratum,sampEffort,replaceResamp)
      # In the case where we are not sampling foreign vessels then the selected PSU can be 
      # slightly different, in that if a sight day only has foreign landings then it wont be sellected 
      if(sampleForeign==FALSE)
      {
        selectedPSU <-sampleFromAGroup(xx$psu[xx$landType=="own"],xx$psuStratum[xx$landType=="own"],sampEffort,replaceResamp)
        #cat("Not sampling foreign vessels so PSU excluded that only have foreign landings\n") 
      }
      # and sampData are all the rows in the popupation data frame that relate to the selected PSUs
      sampData <-xx[which(xx$psu %in% selectedPSU),]
      # the achieved stratum samples sizes are: 
      psuAchieved <-tapply(sampData$psu,sampData$psuStratum,lengthUnique)
      sampData$psuSampled <-psuAchieved[match(sampData$psuStratum,names(psuAchieved))]
      
      # for two stage sampling 
      # the ssu totals are: 
      ssuTotals <-tapply(sampData$ssu,sampData$psu,lengthUnique)
      ssuTotalsOwn <-tapply(sampData$ssu[sampData$landType=="own"],sampData$psu[sampData$landType=="own"],lengthUnique)
      
      sampData$ssuTotal <-ssuTotals[match(sampData$psu,names(ssuTotals))]
      # we set a limit on the sample size of the available ssu
      ssuMaxSamp <-ssuTotals
      #but adjust this if we are not sampling all vessels
      if(sampleForeign==FALSE){
        ssuMaxSamp <-ssuTotalsOwn
        #cat("xenerphobic sampling going on\n")
      }
      # and put an upper limit on the maximum number of samples
      ssuMaxSamp[which(ssuMaxSamp>maxSsuSamp)] <-maxSsuSamp
      # we then pick out the ssu from the psu sample data
      if(sampleForeign==TRUE)
      {
        selectedSSU <-sampleFromAGroup(sampData$ssu,sampData$psu,ssuMaxSamp,replaceResamp)
      }
      if(sampleForeign==FALSE)
      {
        # when not sampling foreign vessel we only select from "own" 
        selectedSSU <-sampleFromAGroup(sampData$ssu[sampData$landType=="own"],sampData$psu[sampData$landType=="own"],ssuMaxSamp,replaceResamp)
      }
      # and extract the ssu sample data set
      sampData2stage <-sampData[which(sampData$ssu %in% selectedSSU),]
      # the numbers of ssu sampled per psu is then..
      ssuSampled <-tapply(sampData2stage$ssu,sampData2stage$psu,lengthUnique)
      sampData2stage$ssuSampled <-ssuSampled[match(sampData2stage$psu,names(ssuSampled))]
      
      # calculate the sample weight one stage  
      # MAIN CHANGE compared to logbook sims - we add a weight based on total catch to estimate a weighted mean length
      sampData$weight <- (sampData$psuTotal/sampData$psuSampled) 
      
      # calculate the sample weight two stage  
      # MAIN CHANGE compared to logbook sims - we add a weight based on total catch to estimate a weighted mean length
      sampData2stage$weight <-sampData2stage$psuTotal/sampData2stage$psuSampled*
        sampData2stage$ssuTotal/sampData2stage$ssuSampled 
      
      
      # calling the survey design function 
      if(singleStage==TRUE)
      {
        svyDStrat <- svydesign(id=~psu,weights=~weight,data=sampData,strata=~psuStratum)
        sampData <-sampData
      }
      if(singleStage==FALSE)
      {
        svyDStrat <- svydesign(id=~psu+ssu,weights=~weight,data=sampData2stage,strata=~psuStratum)
        sampData <-sampData2stage
      }
      # MAIN CHANGE compared to logbook sims - we use "svymean" instead of "svytotal" as dealing with mean length not total weigth
      res <- svyby(svyDStrat$variables[,13:c(ncol(svyDStrat$variables)-12)],by=~sppFac,FUN=svytotal,design=svyDStrat)
      
      simTot <-svytotal(svyDStrat$variables[,13:c(ncol(svyDStrat$variables)-12)],design=svyDStrat)
      resObj$totalEst[i,] <-c(simTot,SE(simTot))
      
      # estimating the weight by stratum and landing country 
      resStrat <-svyby(svyDStrat$variables[,13:c(ncol(svyDStrat$variables)-12)],by=~psuStratum,FUN=svytotal,design=svyDStrat)
      resCtry <-svyby(svyDStrat$variables[,13:c(ncol(svyDStrat$variables)-12)],by=~landCtry,FUN=svytotal,design=svyDStrat)
      eval(parse(text=paste("resDom <-svyby(svyDStrat$variables[,13:c(ncol(svyDStrat$variables)-12)],by=~",domainNames,",FUN=svytotal,design=svyDStrat)",sep="")))
      
     # resDom <-svyby(svyDStrat$variables[,13:c(ncol(svyDStrat$variables)-12)],by=~domainsId,FUN=svytotal,design=svyDStrat)
      
      resObj$strataEst[match(resStrat[,1],resObj$strataList),,i] <- matrix(unlist(resStrat[,-1]),byrow=FALSE,ncol=c(ncol(resStrat)-1))
      resObj$ctryEst[match(resCtry[,1],resObj$ctryList),,i] <- matrix(unlist(resCtry[,-1]),byrow=FALSE,ncol=c(ncol(resCtry)-1))
      resObj$sppEst[match(res[,1],resObj$sppList),,i] <- matrix(unlist(res[,-1]),byrow=FALSE,ncol=c(ncol(res)-1))
      resObj$sppNumber[i,] <- tapply(sampData$fishTripId,factor(sampData$sppFac,levels=resObj$sppList,ordered=TRUE),lengthUnique)
      resObj$domainNumber[i,] <- tapply(sampData$fishTripId,factor(sampData$domainFac,levels=resObj$domainList,ordered=TRUE),lengthUnique)
      resObj$fishTripNumber[i] <- lengthUnique(sampData$fishTripId)
      resObj$sampRowNames[[i]] <- rownames(sampData)
    
      resObj$domainEst[match(row.names(resDom),resObj$domainList),,i] <- matrix(unlist(resDom[,-1]),byrow=FALSE,ncol=c(ncol(resDom)-1))
    }
    # end of the simulation loop 
    #-------------------------------
    resObj$sppNumber[is.na(resObj$sppNumber)] <- 0
    if (verbose==T) print("end sim")
    flush.console()
    
    out[[idx]] <- resObj
    
  }
  

  if(saveResults)
  {
    dateStamp   <- date()
    rdaFileName <-paste(paste(getwd(),"temp",sep="/"),paste(paste("S",simName,"nsim",nsim,gsub(":","-",dateStamp),sep=" "),".rData",sep=""),sep="/")
    save(out,file=rdaFileName)
  }
  
  # this would be where you close the runSim function and return the resObj
  return(out)
}