
setUpData <-function(data,psu="fishTripId",psuStratum,stratumEffort,domains, verbose=T)
{
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # V2 as of 7-8-2018
  
  # setUpData
  # function that takes the fishPi 2 data frame
  # and assignes various columns depending on the user specifications
  # calculates stratum totals
  # calculates ...
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  
  xx <-data
  # library and functions called
  #library(survey)
  #source("C:\\Users\\Pouta\\Documents\\FRS\\fishPi 2\\WP3 code\\sampleFromAGroup.r")
  
  lengthUnique <-function(x){length(unique(x))}
  
  if(!(psu %in% c("fishTripId","vslId","siteXday")))
  {if (verbose==T) cat("psu expected to be fishTripId,vslId,or siteXday\n")}
  
  if(psu %in% "fishTripId")
  {
    xx$psu <-xx$fishTripId
    xx$ssu <-NA
    if (verbose==T) cat("psu is fishTripId, ssu is NA\n")
  }
  if(psu %in% "vslId")
  {
    xx$psu <-xx$vslId
    xx$ssu <-xx$fishTripId
    if (verbose==T) cat("psu is vslId, ssu is fishTripId\n")
  }
  if(psu %in% "siteXday")
  {
    xx$psu <-paste(xx$landLoc,xx$landDate,sep="_")
    xx$ssu <-paste(xx$fishTripId)
    if (verbose==T) cat("psu is siteXday, ssu is fishTripId\n")
  }
  
  
  
  #  the PSU stratum 
  if(missing(psuStratum)){stop("psuStratum missing")}
  
  
  if(length(psuStratum)==1 && toupper(psuStratum)=="RANDOM")
  {
    xx$psuStratum <-"ALL"
    if (verbose==T) cat("Random sampling of psu with no stratification\n")
  }
  
  if(all(psuStratum %in% names(xx)))
  {
    if(length(psuStratum)>1)
    {
      psuST <-paste(psuStratum,collapse="_")
      newvar <-apply(xx[,psuStratum],1,paste,collapse="_")
      xx$psuStratum <-newvar
      stratVar <-psuST
      if (verbose==T) cat("psuStratum is ",psuST,"\n")
    }
    if(length(psuStratum)==1)
    {xx$psuStratum <-xx[,psuStratum]
    stratVar <-psuStratum
    if (verbose==T) cat("psuStratum is ",psuStratum,"\n")
    }}
  
  if(!(all(psuStratum %in% names(xx))))
  {
    if(length(psuStratum)==length(xx[,1]))
    {
      xx$psuStratum <-as.character(psuStratum)
      if (verbose==T) cat("psuStratum is a new variable ",head(xx$psuStratum),"....\n")
    }
    if(toupper(psuStratum) != "RANDOM" && length(psuStratum)!=length(xx[,1]))
    {
      stop("psuStratum expected to be of length ",length(xx[,1]))}
  }
  
  # we make all psuStratum names uppercase
  xx$psuStratum <-toupper(xx$psuStratum)
  
  #stratumEffort
  
  # if stratumEffort is not already a list, turn to list
  if (!is.list(stratumEffort)) { 
    stratumEffort_lst <- list()
    stratumEffort_lst[[1]] <- stratumEffort
    stratumEffort <- stratumEffort_lst}
  
  # first we make all statumEffort names uppercase
  
  #names(stratumEffort) <-toupper(names(stratumEffort))
  stratumEffort <- lapply(stratumEffort, function(x) {
    tmp_names <- toupper(names(x))
    x         <- as.data.frame(matrix(x, ncol=length(x)))
    names(x)  <- tmp_names
    x})
  
  if(length(stratumEffort[[1]])!=lengthUnique(xx$psuStratum))
  {stop("stratumEffort should be the same length as the number of strata\n")}
  if(is.null(names(stratumEffort[[1]])))
  {stop("stratumEffort should be a named vector \n")}
  if (verbose==T) cat("stratum Names are: ",names(stratumEffort[[1]]),"\n")
  if (verbose==T) cat("stratumEffort is: ", unlist(stratumEffort[[1]]),"\n")
  
  
  # the stratum totals are:  
  psuStratumN <-tapply(xx$psu,xx$psuStratum,lengthUnique)
  actualStrata <-names(psuStratumN)
  if (verbose==T) cat("actual Strata are",actualStrata,"\n")
  if(!(all(actualStrata %in% names(stratumEffort[[1]])))){
    stop("startumEffort is missing for some strata\n") }
  
  
  out <- list()
  
  for (effIdx in 1:length(stratumEffort)){
    
    stratumEffort_tmp <- unlist(stratumEffort[[effIdx]])
    
    # the expected stratum samples sizes are: 
    xx$psuPlanned <-stratumEffort_tmp[match(xx$psuStratum,names(stratumEffort_tmp))]
    
    
    # and we map those values to every row in the data frame 
    xx$psuTotal <-psuStratumN[match(xx$psuStratum,names(psuStratumN))]
    
    if (verbose==T) cat("stratum Totals are:",psuStratumN ,"\n")
    if(any(stratumEffort_tmp>psuStratumN))
      warning("stratum Effort greater than stratum total\n")
    
    # for the non sampling of foreign vessels we check that the PSU totals are not less than the planned effort
    
    psuStratumNOwn <-tapply(xx$psu[xx$landType=="own"],xx$psuStratum[xx$landType=="own"],lengthUnique)
    if (verbose==T) cat("stratum Totals for own vessels are:",psuStratumNOwn ,"\n")
    if(any(stratumEffort_tmp>psuStratumNOwn))
      warning("stratum Effort greater than stratum total when sampling only own vessels\n")
    
    
    # we factorise the sppFAO codes and make column sppFac
    sppList <- sort(unique(data$sppFAO))
    xx$sppFac <- factor(xx$sppFAO,levels=sppList,ordered=TRUE)
    
    # if no domains are specified then we default to estimating for the sppFAO
    if(missing(domains))
    {
      xx$domainName <-xx[,"sppFAO"]
      domainNames <-"sppFAO"
      if (verbose==T) cat("no domains specified, using sppFAO\n")
      
    }
    if(!(missing(domains)))
    {
      #xx$domainName <-ifelse(length(domains==1),xx[,domains],apply(xx[,domains],1,paste,collapse="."))
      domainNames <-domains
      if(length(domains)>1)
      {
        xx$domainName <-apply(xx[,domains],1,paste,collapse=".")
        domainNames <-paste(domains,collapse="+")
      }
      if(length(domains)==1)
      {
        xx$domainName <-xx[,domains]
        domainNames <-domains
      }
      if (verbose==T) cat(domains,"specified for estimation\n")
    }
    domainList   <- sort(unique(xx$domainName))
    xx$domainFac <- factor(xx$domainName,levels=domainList,ordered=TRUE)
    
    
    out[[effIdx]] <-list("data"=xx,"psu"=psu,"psuStratumN"=psuStratumN,"stratumEffort"=stratumEffort_tmp,"domainNames"=domainNames)
    
  }
  
  return(out)
}

