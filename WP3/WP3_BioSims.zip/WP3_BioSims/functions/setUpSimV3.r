setUpSim <-function(nsim,data,simName="testSim")
{
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # setUpSum 
  # function that makes the objects to hold the simulation results
  # requires 
  # nsim  - the number of simulations 
  # data - the data frame object, the result of setUpData which has columns for..
  # returns 
  # resObj - a list containing .....
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  
  # data is now a list of myData
  resObj   <- list()
  data_all <- data
  
  if (is.data.frame(data_all[[1]])) {
    data_all_lst <- list()
    data_all_lst[[1]] <- data_all
    data_all <- data_all_lst}
  
  for (dataIdx in 1:length(data_all)){
    
    data = data_all[[dataIdx]]$data
    
    # the unique species, country  
    sppList    <- sort(unique(data$sppFAO))
    ctryList   <- sort(unique(data$landCtry))
    strataList <- sort(unique(data$psuStratum))
    domainLevels <-as.character(sort(unique(data$domainFac)))
    # the number of species, country and stratum 
    Nspp    <- length(sppList)
    Nctry   <-length(ctryList)
    Nstrat  <-length(strataList)
    Ndomain <-length(domainLevels)
    # domains 
    #need to make this more versatile but for now use area
    #domainLevels <- sort(unique(data$area))
    
    # caculate the number of lengths bins 
    Nlen <- ncol(data[,13:c(ncol(data)-9)])
    
    # array to hold the simulation 
    # total and SE  standard error note one total estimate for all 
    totalEst <- array(NA,dim=c(nsim,2*Nlen))
    # total and se for the spp  - assumes we want to estimate for spp
    sppEst <- array(NA,dim=c(Nspp,2*Nlen,nsim))
    # this records the sample size by species 
    sppNumber <- array(NA,dim=c(nsim,Nspp))
    # this records the number of sampled fishing trips
    fishTripNumber <- array(NA,dim=c(nsim))
    if(length(sppList)>1) dimnames(sppNumber)[[2]] <- sppList
    if(length(sppList)>1) dimnames(sppEst)[[1]] <- sppList
    sampRowNames <- list()
    
    domainEst <- array(NA,dim=c(length(domainLevels),2*Nlen,nsim))
    dimnames(domainEst)[[1]] <- domainLevels
    # this records the sample size by domains 
    domainNumber <- array(NA,dim=c(nsim,Ndomain))
    dimnames(domainNumber)[[2]] <- domainLevels
    # estimates by country and stratum 
    ctryEst <- array(NA,dim=c(Nctry,2*Nlen,nsim))
    dimnames(ctryEst)[[1]] <- ctryList
    strataEst <- array(NA,dim=c(Nstrat,2*Nlen,nsim))
    
    if(length(strataList)>1)dimnames(strataEst)[[1]] <- strataList
    #if(length(strataList)==1)dimnames(strataEst)[[1]] <- strataList
    
    
    resObj[[dataIdx]] <-list("sampRowNames"=sampRowNames,"sppEst"=sppEst,"sppNumber"=sppNumber,
                  "fishTripNumber"=fishTripNumber,"ctryEst"=ctryEst,"strataEst"=strataEst,"domainEst"=domainEst,"domainNumber"=domainNumber,"totalEst"=totalEst,"pop"=data,"sppList"=sppList,"ctryList"=ctryList,"strataList"=strataList,"domainList"=domainLevels,"simName"=simName)
  }
  return(resObj)
} 