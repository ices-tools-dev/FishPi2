
require(tidyr)
require(survey)

## Load biological data for 2015
load("data/biodata2015.rdata")

## Source functions
setwd("R\\WP3_final\\functions")
listFn <- list.files()
for (i in 1:length(listFn)) {source(listFn[i])}

## Select the data to work with and calculate the mean length by ssu (i.e. trip)

#offshore sampling of metier TBB_DEF_70-99_0_0 case study
selecDat <- all15[all15$catchCat=="LAN" & all15$foCatEu6=="TBB_DEF_70-99_0_0",]

##xx is the final dataset going forward
xx <- selecDat

## Rename to be able to use functions from main script
names(xx)[names(xx)=="sampFishTripId"] <- "fishTripId"
names(xx)[names(xx)=="loc"]      <- "landLoc"
names(xx)[names(xx)=="sampDate"] <- "landDate"
names(xx)[names(xx)=="sampCtry"] <- "landCtry"

xx_out <- xx

results_out <- list()

## How many simulations?
nsim   <- 1000

# with replacement?
resamp <- TRUE

idx <- 1

for (spp in c("PLE","COD")) { #unique(xx_out$sppFAO)
  
  xx_tmp <- xx_out[xx_out$sppFAO==spp,]
  
  # Put in right format
  agg_biol <- aggregate(estNum ~
                          fishTripId+sampType+vslFlgCtry+landCtry+landDate+ # landLoc removed as not given by the French
                          area+foCatEu6+sppFAO+sppName+lenCls+
                          +year+quarter+landType, data=xx_tmp, sum)
  xx <- spread(agg_biol, lenCls, estNum, fill=0)
  
  # In the same logic, redefine fishing trip as fishing trip x area 
  # so each line is a single unit of sampling
  dim(xx)
  length(unique(xx$fishTripId))
  xx$fishTripId <- paste(xx$fishTripId,xx$area, sep="_")
  length(unique(xx$fishTripId))
  
  ## Define the Strata and allocate the effort
  
  #stratifying by country, using a range of efforts
  #start by checking the full selected dataset
  bioSampSize   <- aggregate(fishTripId ~ landCtry, xx, function(x) length(unique(x)))
  print(bioSampSize)
  #the data call was restricted to a few selected species but the script would work with
  #more species and there would be more 0 data (i.e. trips where a given species was not 
  #sampled)
  #sample all countries in one pool in the present case study, with increasing effort
  myStratum  <-"random"
  myEffort   <- cbind.data.frame(ALL=c(c(seq(5,c(sum(bioSampSize[,2])), by=3)))) # or  CAN GO FOR HIGHER VALUES IF RESAMP WITH REPLACEMENT
  # split 
  myEffort   <- split(myEffort, seq(nrow(myEffort)))
  
  #check the number of fishing trip sampled per domain in the dataset
  #here domains is spp x area
  domainsCheck   <- aggregate(fishTripId ~ area, xx, function(x) 
    length(unique(x)))
  print(domainsCheck)
  
  #define the domain here - this differs from the main script that runs with the logbook data
  #the advantage is taht is creates a new column, making it easier for generic figures
  xx$domainsId   <- xx$area#paste(xx$sppFAO,xx$area, sep="_") 
  
  ## SetUpData sets up the data set, calculates PSU totals, 
  ## and checks the planed sampling effort against the actual Stratum totals    
  
  #vslId should the PSU for sampling at-sea but this is not in the dataset
  #fishTripId would be the ssu but here it is the psu
  #OPTIONS for psu are "fishTripId","vslId","siteXday" ("vslId" does not work for 
  #the biological dataset as missing the vessel ID info - but if "vslId" column existed
  #this option could be run too)
  #domains can be any column names 
  myData <- setUpData(xx, psu="fishTripId",psuStratum=myStratum, myEffort, 
                      domains="domainsId", verbose=F)
  
  ## Set up arrays to hold the results
  myResObj <- setUpSim(nsim,myData)
  
  #here I have added an option to be able to resampling with replacement, but default 
  #is FALSE
  results <- runSim(nsim,myData,maxSsuSamp=NULL,myResObj,sampleForeign=TRUE,
                    replaceResamp=resamp,verbose=F) 
  
  # if nsim > 1 then we calculate some summary results 
  calcs   <- calcRes(results)
  
  #### Plot domains
  rses <- c()
  for (i in 1:length(calcs)){
    rses_tmp <- cbind.data.frame(myEffort[[i]][1], calcs[[i]]$domRSEest, doms= dimnames(calcs[[i]]$domRSEest)[[1]])
    names(rses_tmp) <- c("sampSize","RSE","domain")
    rses <- rbind(rses, rses_tmp)
  }
  library(ggplot2)
  g1 <-  ggplot(rses, aes(sampSize, RSE, group=domain)) + 
    geom_line(aes(color=domain)) + ggtitle(spp)
  
  print(g1)
  
  #### Plot main - spp not by domain
  rses <- c()
  for (i in 1:length(calcs)){
    rses_tmp <- cbind.data.frame(myEffort[[i]][1], calcs[[i]]$RSEest)
    names(rses_tmp) <- c("sampSize","RSE")
    rses <- rbind(rses, rses_tmp)
  }
  library(ggplot2)
  g2 <-  ggplot(rses, aes(sampSize, RSE)) +
    geom_line() + ggtitle(spp)

  print(g2)
  
  # get output for each species so can put all species on one plot after if needs be
  results_out[[idx]] <- calcs
  names(results_out[[idx]]) <- spp
  
  idx <- idx + 1
  
  print(paste(spp, "done"))
  
}

# get results for cod and plaice for xx samples - functions below work only for one sampling effort at a time
idx_eff <- 10 # 10th value of the Effort gradient tested

# plot estimated mean against population - requires combining species - could be tidied up - here combines PLE and COD
calcs <- list()
calcs[[1]] <- rbind(results_out[[1]][[idx_eff]]$sppCiUp,results_out[[2]][[idx_eff]]$sppCiUp)
calcs[[2]] <- rbind(results_out[[1]][[idx_eff]]$sppCiLo,results_out[[2]][[idx_eff]]$sppCiLo)
calcs[[3]] <- rbind(results_out[[1]][[idx_eff]]$sppPop,results_out[[2]][[idx_eff]]$sppPop)
calcs[[4]] <- rbind(results_out[[1]][[idx_eff]]$meanSppEst,results_out[[2]][[idx_eff]]$meanSppEst)
calcs[[5]] <- rbind(results_out[[1]][[idx_eff]]$domCiUp,results_out[[2]][[idx_eff]]$domCiUp)
calcs[[6]] <- rbind(results_out[[1]][[idx_eff]]$domCiLo,results_out[[2]][[idx_eff]]$domCiLo)
calcs[[7]] <- matrix(c(results_out[[1]][[idx_eff]]$domPop,results_out[[2]][[idx_eff]]$domPop), ncol=1)
calcs[[8]] <- rbind(results_out[[1]][[idx_eff]]$meanDomEst,results_out[[2]][[idx_eff]]$meanDomEst)

names(calcs) <- c("sppCiUp","sppCiLo","sppPop","meanSppEst","domCiUp","domCiLo","domPop","meanDomEst")
names(calcs$domPop) <- c(paste("ple",names(results_out[[1]][[idx_eff]]$domPop)),
                         paste("cod",names(results_out[[2]][[idx_eff]]$domPop)))

devPlot(calcs)

# plot bias
calcs[[9]] <- rbind(results_out[[1]][[idx_eff]]$sppSampSize,results_out[[2]][[idx_eff]]$sppSampSize)
calcs[[10]] <- rbind(results_out[[1]][[idx_eff]]$sppBiasEst,results_out[[2]][[idx_eff]]$sppBiasEst)
calcs[[11]] <- rbind(results_out[[1]][[idx_eff]]$domSampSize,results_out[[2]][[idx_eff]]$domSampSize)
calcs[[12]] <- rbind(results_out[[1]][[idx_eff]]$domBiasEst,results_out[[2]][[idx_eff]]$domBiasEst)

names(calcs)[9:12] <- c("sppSampSize","sppBiasEst","domSampSize","domBiasEst")
names(calcs$domSampSize) <- c(paste("ple",names(results_out[[1]][[idx_eff]]$domSampSize)),
                              paste("cod",names(results_out[[2]][[idx_eff]]$domSampSize)))

biasPlot(calcs)


# plot sims means (red) compared to true mean (green)

par(mfrow=c(2,3))

# per domain - in this case spp x area - PLE
dimnames(results_out[[1]][[idx_eff]]$domEstsims)[1] <- list(paste("ple",names(results_out[[1]][[idx_eff]]$domPop)))
calcs[[13]] <- results_out[[1]][[idx_eff]]$domEstsims
names(calcs)[13] <- c("domEst")

domHist(calcs, paste("ple",unique(xx$domainsId)))
  
# per domain - in this case spp x area - COD
dimnames(results_out[[2]][[idx_eff]]$domEstsims)[1] <- list(paste("cod",names(results_out[[2]][[idx_eff]]$domPop)))
calcs[[13]] <- results_out[[2]][[idx_eff]]$domEstsims
names(calcs)[13] <- c("domEst")

domHist(calcs, paste("cod",unique(xx$domainsId)))
