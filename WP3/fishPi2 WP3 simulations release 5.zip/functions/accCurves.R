accCurves <- function (obj, sppHighlighted = c("COD","POK","HAD","PLE","SOL","HKE")){

# to test whether sufficient simulations have been run, using accumulation curves of all species
  # obj is the results list output from runSim 


dat <- obj

#dots <-list(...)
#if(is.null(dots$col)){dots$col <- "#80B1D3"}


  
resultsAccCurves <- array(NA,dim=c(nsim,(2+lengthUnique(dat$sppList))))
colnames(resultsAccCurves) <- c("TotalRSE", "OverallDeviation", unique(dat$sppList) )

for (i in 1:nsim){
  simTotEst <-calcs$totEst[1:i]
  meanTotEst <-mean(simTotEst)
  sdTotEst <-sd(simTotEst)
  resultsAccCurves[i,1] <-100*(mean((simTotEst-sum(dat$pop$landWt))/sum(dat$pop$landWt)))
  resultsAccCurves[i,2] <- sdTotEst/meanTotEst
  for (j in 1:lengthUnique(dat$sppList)){
    resultsAccCurves[i,2+j] <- sd(dat$sppEst[unique(dat$sppList)[j],1,][1:i],na.rm=T)/mean(dat$sppEst[unique(dat$sppList)[j],1,][1:i],na.rm=T)
  } 
}
par(mfrow = c(2,1))
plot(resultsAccCurves[,1], type = "l", xlab = "nsim", ylab = "Overall % deviation", main = paste("Simulation accumulation curves for", scenario, totalEffort))
plot(resultsAccCurves[,2], type = "l", xlab = "nsim", ylab = "RSE", ylim = c(0,max(resultsAccCurves[,2:(2+lengthUnique(dat$sppList))],na.rm = T)+0.5), main = "Relative standard error for all fish species")
for (k in 1:lengthUnique(dat$sppList)){
  points(resultsAccCurves[,(2+k)], type = "l", col = "grey")
}

library(RColorBrewer)
if(length(sppHighlighted) < 9) colours <- brewer.pal(length(sppHighlighted), "Set1")

for(j in 1:length(sppHighlighted)){
points(resultsAccCurves[,sppHighlighted[j]], type = "l", col = colours[j])
}
points(resultsAccCurves[,2], type = "l", col = "black", lwd = 1.5)
legend("topleft", legend=c(append("Overall",sppHighlighted)),
       col=c(append("black",colours)), lty=1, cex=0.7, horiz = T)

}
#-------------------------------------------------------------------------------#
