createPortAllocations <- function(x, percentMajor = 90, by = "landWt", areaSelection = widerNSea, ISSCAAPSelection = demISSCAAP){
  
  # function to allocate ports according to landWt or fishTripId and merge selection to portFrame
  
  x <- x[x$area %in% areaSelection & x$ISSCAAP %in% ISSCAAPSelection,]
  rank_landLoc <- rankingFp2Variable(x, grouping_variable = "landLoc")
  
  if(by == "landWt"){portAlloc <- rank_landLoc$landLoc[which(rank_landLoc$cum_per_land <= percentMajor)]}
  if(by == "fishTripId"){portAlloc <- rank_landLoc$landLoc[which(rank_landLoc$cum_per_trips <= percentMajor)]}
  
  portFrame$newPortAllocation <- portTypeAllocation(portFrame, by = portAlloc[portAlloc %in% unique(portFrame$loCode)], portCode = "loCode")
  print(table(portFrame$newPortAllocation))
  return(portFrame$newPortAllocation)
}
