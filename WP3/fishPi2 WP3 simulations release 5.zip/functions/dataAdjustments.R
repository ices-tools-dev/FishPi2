dataAdjustments <- function(dat){

# Simplify gears
dat$foCatReg <- dat$foCatEu6
dat$foCatReg <- gsub("OTB","OTC",dat$foCatReg)
dat$foCatReg <- gsub("PTB","OTC",dat$foCatReg)
dat$foCatReg <- gsub("OTT","OTC",dat$foCatReg)
dat$foCatReg[!(substr(dat$foCatReg,1,3) %in% c("OTC","TBB","SSC","GNS","SDN","GTR"))] <- "MIS_MIS_0_0_0"

dat$sppReg <- dat$sppFAO
# group subspecies 
dat$sppReg[dat$sppFAO == "MNZ" |dat$sppFAO == "MON" |dat$sppFAO == "ANK"] <- "ANF"
dat$sppReg[dat$sppFAO == "MEG" |dat$sppFAO == "LBD" ] <- "LEZ"
# group sepcies not of interest
dat$sppReg[!(dat$sppFAO %in% fishOfInterest)] <- "ZZZ"

# move GBW to GBE
dat$landCtry[dat$landCtry =="GBW"] <- "GBE"
dat$vslFlgCtry[dat$vslFlgCtry =="WLS"] <- "ENG"

cat("Data ready\n")
return(dat)

}