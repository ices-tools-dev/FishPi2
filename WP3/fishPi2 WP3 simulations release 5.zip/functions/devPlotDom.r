#-------------- for domain results---------------------------------

#--------------bias and var plot v pop weight----------------------

devPlotDom <-function(calcs,...)
{
  #par(ask=T)
  dots <- list(...)   
  if (is.null(dots$ylim))dots$ylim <-c(0,max(calcs$domCiUp,na.rm=TRUE))
  if (is.null(dots$xlab))dots$xlab <-"True total"
  if (is.null(dots$ylab))dots$ylab <-"Estimated total" 
  if (is.null(dots$cex))dots$cex <- 0.5 
  
  plot(calcs$domainPop,calcs$meanDomEst,ylim=dots$ylim,type="n",xlab=dots$xlab,ylab=dots$ylab)
  points(calcs$domainPop,calcs$meanDomEst,pch=16,cex=0.7)
  text(calcs$domainPop,calcs$meanDomEst,names(calcs$domainPop),cex=dots$cex,pos=4)
  segments(calcs$domainPop,calcs$domCiLo,calcs$domainPop,calcs$domCiUp)
  abline(0,1,col="grey")
  return("All Done")
}
#-----------------------------------------------------------------------------
biasPlotDom <-function(calcs,...)
{
  #-----------bias plot------------------------------
  dots <- list(...)   
  if (is.null(dots$ylim))dots$ylim <-c(-20,20)
  if (is.null(dots$xlab))dots$xlab <-"Sample size"
  if (is.null(dots$ylab))dots$ylab <-"% deviation" 
  if (is.null(dots$cex))dots$cex <- 0.5
  
  plot(calcs$domSampSize,calcs$domBiasEst,type="n",ylim=dots$ylim,xlab=dots$xlab,ylab=dots$ylab)
  points(calcs$domSampSize,calcs$domBiasEst,pch=16,cex=0.7)
  text(calcs$domSampSize,calcs$domBiasEst,names(calcs$domSampSize),cex=dots$cex,pos=1)
  abline(h=c(-10,-5,5,10),col="grey")
  abline(h=c(0),col="grey",lty=2)
  #------------------------------------------------------------
  return("All Done")
}

