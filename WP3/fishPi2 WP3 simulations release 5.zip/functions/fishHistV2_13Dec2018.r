fishHist <-function(calcs,fish)
{
index <-which(fish %in% row.names(calcs$sppEst))
fish <-fish[index]
for(i in 1:length(fish)){
hist(calcs$sppEst[fish[i],1,],nclass=30,xlab="Estimated total",main=(fish[i]),density=30,col=2)
abline(v=calcs$sppPop[fish[i]],col=3,lty=1,lwd=4)
abline(v=mean(calcs$sppEst[fish[i],1,],na.rm=T),col=2,lty=1,lwd=2)
abline(v=median(calcs$sppEst[fish[i],1,],na.rm=T),col="purple",lty=1,lwd=1)
abline(v=calcs$sppCiUp[fish[i]],col=2,lty=2)
abline(v=calcs$sppCiLo[fish[i]],col=2,lty=2)
}
return("All Done")
}