getStratum <- function (dat,stratification = c("random", "sampNow", "landCtry", "landLocType"), 
                        samplingExclusions = c("minor","ESP","NOR","GBI","IRE")){
  
  # scenario                Character string providing a unique identifier for the simulation and its outputs (required)
  # stratification:         Used to create the sampled strata. If a variable in the dataframe, the variable values will be used. Multiple variables can be used. 
  #                         If not a dataframe variable, then the character string text will be applied. 
  #                         For unstratified sampling use "random"
  # samplingExclusions:     (optional) Strata including these character strings will be excluded from the sampled strata. 
  #                                    For random sampling with exclusions, use an additional stratification variable e.g. use landLocType to exclude minor ports

if("sampNow" %in% stratification)
{
  myStratum <-paste(dat$landCtry,dat$landLocType,dat$sampledNow,sep="_") 
  myStratum[grep("nope",myStratum)] <-"none"
 }

if(!"sampNow" %in% stratification){
  
  varStrat <- stratification[stratification %in% names(dat)]
  txtStrat <- stratification[!stratification %in% names(dat)]
  
  if(length(varStrat) == 0 & length(txtStrat) == 1){ myStratum <-rep(paste(txtStrat), length(row.names(dat))) } 
  if(length(varStrat) == 1 & length(txtStrat) == 1){ myStratum <-paste(txtStrat,dat[,varStrat],sep="_") }
  if(length(varStrat) == 2 & length(txtStrat) == 1){ myStratum <-paste(txtStrat,dat[,varStrat[1]],dat[,varStrat[2]],sep="_") }
  if(length(varStrat) == 1 & length(txtStrat) == 0){ myStratum <-paste(dat[,varStrat]) }
  if(length(varStrat) == 2 & length(txtStrat) == 0){ myStratum <-paste(dat[,varStrat[1]],dat[,varStrat[2]],sep="_") }
  if(length(varStrat) == 3 & length(txtStrat) == 0){ myStratum <-paste(dat[,varStrat[1]],dat[,varStrat[2]],dat[,varStrat[3]],sep="_") }
  
  # apply sampling exclusions
  if(!(length(samplingExclusions) == 0)){
    for(i in 1:length(samplingExclusions))
      myStratum[grep(samplingExclusions[i],myStratum)] <-"none"
    }
  
  myStratum[grep("NA",myStratum)] <-"none"
  print(table(myStratum,useNA="always"))
 return(myStratum)
  }
}
