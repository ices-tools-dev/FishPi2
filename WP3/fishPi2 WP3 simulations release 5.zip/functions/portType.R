portType <- function(dat, portAllocation = c("none","new","sampNow","majorPorts95"), portFrameFile = portFrame){
  
  # function to allocate the portType to the original dataset
  
  if(portAllocation == "none"){
    xx$landLocType <- "none"
    cat("No port allocation applied\n")
    print(table(xx$landLocType,useNA="always"))
    return(xx$landLocType)
  }
  
  if(portAllocation == "new"){
    xx$landLocType <-portFrame$newPortAllocation[match(xx$landLoc,portFrame$loCode)]
    cat("New port allocations complete \n")
    print(table(xx$landLocType,useNA="always"))
    return(xx$landLocType)
  }
  
  if(portAllocation == "sampNow"){
    xx$sampledNow <-portFrame$sampled[match(xx$landLoc,portFrame$loCode)]
    table(xx$sampledNow,useNA="always")
    levels(xx$sampledNow) <-c("no","yes","nope")
    xx$sampledNow[which(!(xx$sampledNow %in% "yes"))] <-"nope"   # grep pulls out the "no" in minor if not changed
    cat("Ports allocated according to current sampling\n")
    print(table(xx$sampledNow,useNA="always"))
    return(xx$sampledNow)
  }
  
  if(portAllocation != "sampNow" & portAllocation != "new"){
    xx$landLocType <-portFrame[,portAllocation][match(xx$landLoc,portFrame$loCode)]
    xx$landLocType[is.na(xx$landLocType)] <- "minor"
    cat("Ports allocated using '",portAllocation, "' in portFrame","\n")
    print(table(xx$landLocType,useNA="always"))
    return(xx$landLocType)
  }
}
