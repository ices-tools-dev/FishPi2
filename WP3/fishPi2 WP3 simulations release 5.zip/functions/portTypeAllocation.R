portTypeAllocation <- function(obj, by = portAlloc, portCode = "landLoc"){

    # function for allocating the port type after using the rankingFp2Variable function
  
  obj$landLocType[obj[,c(portCode)] %in% by] <- "major"
  obj$landLocType[!obj[,c(portCode)] %in% by] <- "minor"
  return(obj$landLocType)
}
