rankingFp2Variable <- function(data, grouping_variable = landLoc) {
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# to create informative dataframe: landings, number of trips, etc
# to be used for the selection of strata by criteria of % of landings or % of trips
# e.g. landLoc   rankingFp2Variable(ibe15, "ibe15$landLoc")
# need: tidyverse package
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  library(tidyverse)
    ranking <- data %>%
        group_by_(grouping_variable) %>%
        summarise(landings = sum(landWt), n_trips = n_distinct(fishTripId)) %>%
        arrange(desc(landings)) %>%
        mutate(total_lan = sum(landings)) %>%
        mutate(per_land = round(landings*100/total_lan, 4)) %>%
        mutate(cum_per_land = cumsum(per_land)) %>%
        arrange(desc(landings)) %>%
        mutate(rank_land = 1:n()) %>%
        arrange(desc(n_trips)) %>%
        mutate(total_trips = sum(n_trips)) %>%
        mutate(per_trips = n_trips*100/total_trips) %>%
        mutate(cum_per_trips = cumsum(per_trips)) %>%
        arrange(desc(n_trips)) %>%
        mutate(rank_trips = 1:n()) %>%
        arrange(desc(landings)) %>%
        select(grouping_variable, landings, per_land, cum_per_land, rank_land, n_trips, per_trips, cum_per_trips, rank_trips) %>%
        print(n = nrow(.))

}


   