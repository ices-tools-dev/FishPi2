runSim <-function(nsim,dat,maxSsuSamp,resObj,sampleForeign=TRUE,saveResults=FALSE, saveLoc="X:/fishPi2/simulation output/", simName="test"){
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# runSim
# function that runs nsim simulations 
# from the provided data
# stratified single stage random sampling 
# arguments 
# nsim number of simulations from 1 to many
# data  - the population data frame with columns for ...
#   psu - the primary sampling unit
#   psuStratum the stratum for the psu
# resObj - a list object with varoius vectors for keeping the simulation results
# saveResults=FALSE if TRUE the results object will be saved to a file temp in the working directory
# simName - a character vector for the naming of the simulation 
# 
# Returns a resObj the results object a list consisting of:   
# species estimates
# ....

# runSim v2 sept 2018
# changes: 
# bug fix in sampData is assigned from sampData2 
# otherwise the number of sampled trips is too large in the two stage sampling
# line 110-119
# sampleForeign added that operates on landType ("own" or "foreign") 
# and mimics the situation where foreign vessels are not sampled on-shore locations
#  
# JC edit 07/12/2018
# trying to remove NAs from domainSampSize in the calc results:
# added at line 147: resObj$domainNumber[is.na(resObj$domainNumber)] <- 0
# JC edit 28/03/2019
# added saveLoc specification 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#assign the data to xx
xx <-dat$data
sampEffort <-dat$stratumEffort
domainNames <-dat$domainNames
# functions
lengthUnique <-function(x){length(unique(x))}
if(all(is.na(xx$ssu))) {
singleStage <-TRUE
cat("ssu is NA so doing single stage sampling\n")
}
if(!(all(is.na(xx$ssu)))) {
cat("ssu is populated so doing two stage sampling\n")
singleStage <-FALSE
}
if(sampleForeign==FALSE)cat("Not sampling foreign vessels\n")
# run the simulations
cat("Starting now\n")
for(i in 1:nsim)
{
 if (nsim>=10) {
    if ( (i/round(nsim/10)) - (i %/% round(nsim/10)) == 0 ){
      print(paste(i,date()));flush.console()
    }
    } else {
      print(paste(i,date()));flush.console()  
    }
# first we sample the population data frame 
# selecting the $psu according to psuStratum with the number of samples
# for each strata given by sampEffort
selectedPSU <-sampleFromAGroup(xx$psu,xx$psuStratum,sampEffort)
# In the case where we are not sampling foreign vessels then the selected PSU can be 
# slightly different, in that if a sight day only has foreign landings then it wont be selected 
if(sampleForeign==FALSE)
{
selectedPSU <-sampleFromAGroup(xx$psu[xx$landType=="own"],xx$psuStratum[xx$landType=="own"],sampEffort)
#cat("Not sampling foreign vessels so PSU excluded that only have foreign landings\n") 
}
# and sampData are all the rows in the popupation data frame that relate to the selected PSUs
sampData <-xx[which(xx$psu %in% selectedPSU),]
# the achieved stratum samples sizes are: 
psuAchieved <-tapply(sampData$psu,sampData$psuStratum,lengthUnique)
sampData$psuSampled <-psuAchieved[match(sampData$psuStratum,names(psuAchieved))]

# for two stage sampling 
# the ssu totals are: 
ssuTotals <-tapply(sampData$ssu,sampData$psu,lengthUnique)
ssuTotalsOwn <-tapply(sampData$ssu[sampData$landType=="own"],sampData$psu[sampData$landType=="own"],lengthUnique)

sampData$ssuTotal <-ssuTotals[match(sampData$psu,names(ssuTotals))]
# we set a limit on the sample size of the available ssu
ssuMaxSamp <-ssuTotals
#but adjust this if we are not sampling all vessels
if(sampleForeign==FALSE){
ssuMaxSamp <-ssuTotalsOwn
#cat("xenerphobic sampling going on\n")
}
# and put an upper limit on the maximum number of samples
ssuMaxSamp[which(ssuMaxSamp>maxSsuSamp)] <-maxSsuSamp
# we then pick out the ssu from the psu sample data
if(sampleForeign==TRUE)
{
selectedSSU <-sampleFromAGroup(sampData$ssu,sampData$psu,ssuMaxSamp)
}
if(sampleForeign==FALSE)
{
# when not sampling foreign vessel we only select from "own" 
selectedSSU <-sampleFromAGroup(sampData$ssu[sampData$landType=="own"],sampData$psu[sampData$landType=="own"],ssuMaxSamp)
}
# and extract the ssu sample data set
sampData2stage <-sampData[which(sampData$ssu %in% selectedSSU),]
# the numbers of ssu sampled per psu is then..
ssuSampled <-tapply(sampData2stage$ssu,sampData2stage$psu,lengthUnique)
sampData2stage$ssuSampled <-ssuSampled[match(sampData2stage$psu,names(ssuSampled))]

# calculate the sample weight one stage  
sampData$weight <-sampData$psuTotal/sampData$psuSampled

# calculate the sample weight two stage  
sampData2stage$weight <-sampData2stage$psuTotal/sampData2stage$psuSampled*sampData2stage$ssuTotal/sampData2stage$ssuSampled


# calling the survey design function 
if(singleStage==TRUE)
{
svyDStrat <- svydesign(id=~psu,weights=~weight,data=sampData,strata=~psuStratum)
sampData <-sampData
}
if(singleStage==FALSE)
{
svyDStrat <- svydesign(id=~psu+ssu,weights=~weight,data=sampData2stage,strata=~psuStratum)
sampData <-sampData2stage
}
res <- svyby(~landWt,by=~sppFAO,FUN=svytotal,design=svyDStrat)


simTot <-svytotal(~landWt,design=svyDStrat)
resObj$totalEst[i,c(1,2)] <-c(simTot,SE(simTot))

# estimating the weight by stratum and landing country 
resStrat <-svyby(~landWt,by=~psuStratum,FUN=svytotal,design=svyDStrat)
resCtry <-svyby(~landWt,by=~landCtry,FUN=svytotal,design=svyDStrat)
eval(parse(text=paste("resDom <-svyby(~landWt,by=~",domainNames,",FUN=svytotal,design=svyDStrat)",sep="")))



resObj$strataEst[match(resStrat[,1],resObj$strataList),,i] <- matrix(unlist(resStrat[,2:3]),byrow=FALSE,ncol=2)
resObj$ctryEst[match(resCtry[,1],resObj$ctryList),,i] <- matrix(unlist(resCtry[,2:3]),byrow=FALSE,ncol=2)
resObj$sppEst[match(res[,1],resObj$sppList),,i] <- matrix(unlist(res[,2:3]),byrow=FALSE,ncol=2)
resObj$sppNumber[i,] <- tapply(sampData$fishTripId,factor(sampData$sppFac,levels=resObj$sppList,ordered=T),lengthUnique)
resObj$domainNumber[i,] <- tapply(sampData$fishTripId,factor(sampData$domainFac,levels=resObj$domainList,ordered=T),lengthUnique)
resObj$fishTripNumber[i] <- lengthUnique(sampData$fishTripId)
resObj$sampRowNames[[i]] <- rownames(sampData)
resObj$ssuSampledPerPSU[[i]] <- ssuSampled

res1 <-matrix(unlist(resDom[,((dim(resDom)[2])-1):(dim(resDom)[2])]),byrow=FALSE,ncol=2)
resObj$domainEst[match(row.names(resDom),resObj$domainList),,i] <-res1 
}
# end of the simulation loop 
#-------------------------------
resObj$sppNumber[is.na(resObj$sppNumber)] <- 0
resObj$domainNumber[is.na(resObj$domainNumber)] <- 0

print("end sim")
flush.console()

if(saveResults)
{
dateStamp <- date()
rdaFileName <-paste(saveLoc,paste("S",simName,"nsim",nsim,"effort",totalEffort ,gsub(":","-",dateStamp),sep=" "),".rData",sep="")
save(resObj,file=rdaFileName)
}
# close the runSim function and return the resObj
return(resObj)
}