sampleFromAGroup <- function(x,y,nsize) {
  # x defines the sampling units to be sampled
  # y defines the groups from which to sample 
  # nsize is a vector giving the sample sizes in each group, named according to the unique values in y
  # the values in y need to match the names of nsize
                                                  
  nGroup <- length(nsize)
  xSamp <- NULL
  for (i in 1:nGroup) {
    indx <- unique(x[which(y==names(nsize)[i])])
    samp <- sample(indx,size=nsize[i],replace=FALSE)
    if (i==1) {
      xSamp <- samp
    } else {
      xSamp <- c(xSamp,samp)
    } 
  }
  return(xSamp)
}
